# Synthetic MicrobLiver Dataset

## Overview
This folder contains synthetic datasets that mimic the structure of the MicrobLiver alcohol challenge study. These datasets are designed to work with the analysis functions in `functions.R`.

## Study Design
- **Total participants**: 39
  - ALD (Alcohol-related Liver Disease): 14 patients
  - NAFLD (Metabolic-associated Fatty Liver Disease): 15 patients
  - Healthy controls: 10 participants
- **Time points**: 0, 60, 180 minutes (after alcohol intervention)
- **Sample sites**: Hepatic (liver) and Systemic (peripheral blood)
- **Measurements per participant**: 6 (3 time points × 2 sampling sites)

## Datasets

### 1. plasma_metabolites_matrix.rds
- **Features**: 34 metabolites
- **Dimensions**: 234 rows × 41 columns
- **Feature naming**: Metabolite_001 to Metabolite_034

### 2. plasma_lipidomics_matrix.rds
- **Features**: 283 lipids
- **Dimensions**: 234 rows × 290 columns
- **Feature naming**: Lipid_001 to Lipid_283

### 3. plasma_proteomics_matrix.rds
- **Features**: 77 proteins (Olink)
- **Dimensions**: 234 rows × 84 columns
- **Feature naming**: Protein_001 to Protein_077

### 4. plasma_MS_proteomics_matrix.rds
- **Features**: 150 MS-based proteins
- **Dimensions**: 234 rows × 157 columns
- **Feature naming**: MSProtein_001 to MSProtein_150

## Data Structure

Each dataset contains the following columns:

### Metadata columns (first 7 columns):
1. **Specimenno**: Unique specimen identifier (e.g., "ALD_001_hepatic_T0")
2. **SampleID**: Sample identifier (e.g., "S1_hepatic_0")
3. **PatientID**: Patient identifier (e.g., "ALD_001")
4. **pheno**: Phenotype/disease group (factor with levels: "Healthy", "ALD", "NAFLD")
5. **time**: Time point (factor with levels: "0", "60", "180")
6. **sampleSite**: Sampling location (factor with levels: "hepatic", "systemic")
7. **split_col**: Separator column (all NA values)

### Feature columns (columns 8+):
- Numeric values representing measured concentrations
- Already preprocessed: log10 transformed and scaled
- Some features have built-in phenotype effects (ALD vs NAFLD vs Healthy)
- Some features have time-dependent changes
- Some features show hepatic vs systemic differences

## Data Properties

The synthetic data includes:
- **Phenotype effects**: Different baseline levels for ALD, NAFLD, and Healthy groups
- **Time effects**: Some features change over the 180-minute observation period
- **Site effects**: Some features differ between hepatic and systemic samples
- **Random variation**: Normal distribution with realistic variance

## Usage with Analysis Functions

These datasets are compatible with the functions in `functions.R`:

### Reading data:
```r
source("functions.R")
data_dir <- "path/to/preprocessData/"

# Read metabolites for hepatic samples only
metabolites <- readFile(name = "plasma_metabolites",
                       data_dir = data_dir,
                       sampleSite = "hepatic")
```

### Running Linear Mixed Models:
```r
results <- LMM_time(
  name = "plasma_metabolites",
  ID = "PatientID",
  fixedEffect = "time",
  groupBy = "pheno",
  data_dir = data_dir,
  results_dir = "path/to/results/",
  models_dir = "path/to/models/",
  sampleSite = "hepatic",
  overwrite = TRUE,
  padj_method = "fdr"
)
```

### Creating visualizations:
```r
# Volcano plots
plots <- volcanoPlot_time(results, pvalue = "padj")

# Chord diagrams (requires multi-omics data)
# See functions.R for getChordDiag() and getCircularHeatmap()
```

## Required R Packages

To use these datasets with the full analysis pipeline, you'll need:
- `lmerTest` - Linear mixed-effects models
- `caret` - Near-zero variance detection
- `ggplot2` - Visualization
- `ggrepel` - Label repelling in plots (for volcano plots)
- `RColorBrewer` - Color palettes
- `Hmisc` - rcorr function (for chord diagrams)
- `circlize` - Circular visualizations
- `ComplexHeatmap` - Advanced heatmaps

## Notes

1. **Random names**: All feature names are generic (Metabolite_XXX, Lipid_XXX, etc.) to protect original data
2. **Synthetic values**: All concentration values are randomly generated and do not represent real biological measurements
3. **Structure only**: This dataset is intended to demonstrate data structure and test analysis workflows, not for biological interpretation
4. **Reproducibility**: Generated with `set.seed(123)` for reproducibility

## File Locations

All RDS files are saved in the `preprocessData/` directory:
- `plasma_metabolites_matrix.rds`
- `plasma_lipidomics_matrix.rds`
- `plasma_proteomics_matrix.rds`
- `plasma_MS_proteomics_matrix.rds`

## Original Study Reference

This synthetic dataset is modeled after:
Israelsen M, Kim M, Suvitaival T, et al. Comprehensive lipidomics reveals phenotypic differences in hepatic lipid turnover in ALD and NAFLD during alcohol intoxication. JHEP Reports. 2021;3(5):100325.
